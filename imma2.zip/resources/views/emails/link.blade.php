<html>
<body>
Please follow this <a href="{{$url}}">link</a> to upload document to slot {{$slot+1}}. <br>

{{$url}}

</body>
</html>