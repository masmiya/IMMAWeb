<html>
<body>
Here are the requests to IMMA.

<table>
	<th>
		<td>No</td>
		<td>Imma Code</td>
		<td>Name</td>
		<td>Count</td>
		<td>Description</td>
	</th>

	<?php $no=0 ?>
	<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php $no ++; ?>
	<tr>
		<td><?php echo e($no); ?></td>
		<td>
			<?php if(isset($item["imma_id_code"])): ?>
				<?php echo e($item["imma_id_code"]); ?>

				<?php else: ?>
				&nbsp;
			<?php endif; ?>
		</td>
		<td>
			<?php if(isset($item["name"])): ?>
				<?php echo e($item["name"]); ?>

				<?php else: ?>
				&nbsp;
			<?php endif; ?>
		</td>
		<td>
			<?php if(isset($item["count"])): ?>
			<?php echo e($item["count"]); ?>

			<?php else: ?>
				&nbsp;
			<?php endif; ?>
		</td>
		<td>
			<?php if(isset($item["description"])): ?>
			<?php echo e($item["description"]); ?>

			<?php else: ?>
				&nbsp;
			<?php endif; ?>
		</td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

</body>
</html>