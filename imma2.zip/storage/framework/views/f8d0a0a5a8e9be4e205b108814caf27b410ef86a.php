
<?php $__env->startSection('title', 'Edit Category'); ?>
<?php $__env->startSection('header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div id="wrapper">

        <!-- Navigation -->
        <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Edit Category</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Category Information
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">

                            <!-- /.table-responsive -->

                            <form method="post" action="<?php echo e(url('/categories/')); ?>/<?php echo e($category->id); ?>/edit" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label>Category Name</label>
                                    <input class="form-control" name="name" value="<?php echo e($category->name); ?>">
                                </div>

                                <div class="form-group">
                                    <label>Order</label>
                                    <input class="form-control" name="order" value="<?php echo e($category->order); ?>">
                                </div>

                                <div class="form-group">
                                    <label>Information</label>
                                    <input class="form-control" name="info" value="<?php echo e($category->info); ?>">
                                </div>

                                <div class="form-group">
                                    <input type="submit" class="btn btn-primary">
                                </div>
                            </form>

                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->

                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Subcategory Information
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Sub Category Name</th>
                                    <th>Order</th>
                                    <th>Delete</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="odd gradeX datarow" data-id="<?php echo e($category->id); ?>" data-subid="<?php echo e($subcategory->id); ?>">
                                        <td><?php echo e($subcategory->id); ?></td>
                                        <td><?php echo e($subcategory->name); ?></td>
                                        <td><?php echo e($subcategory->order); ?></td>
                                        <td class="center remove-row">
                                            <a href="<?php echo e(url('categories/')); ?>/<?php echo e($category->id); ?>/subcategories/<?php echo e($subcategory->id); ?>/delete">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr class="odd gradeA">
                                        <td colspan="5">No records</td>
                                    </tr>
                                <?php endif; ?>

                                </tbody>
                            </table>

                            <a class="btn btn-primary" href="<?php echo e(url('categories/')); ?>/<?php echo e($category->id); ?>/subcategories/new">Add Category</a>
                        </div>
                    </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $('#dataTables-example').DataTable({
                responsive: true
            });

            $('.datarow').click(function (e){
                var id = $(this).data('id')
                var subid = $(this).data('subid')
                window.location.href = "<?php echo e(url('/categories/')); ?>/" + id + "/subcategories/" + subid + "/edit"
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>