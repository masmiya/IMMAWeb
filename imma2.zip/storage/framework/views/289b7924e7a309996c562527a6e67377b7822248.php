
<?php $__env->startSection('title', 'Ports - New'); ?>
<?php $__env->startSection('header'); ?>

    <![endif]-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div id="wrapper">

        <!-- Navigation -->
        <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">New Port</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Port Information
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">

                            <!-- /.table-responsive -->

                            <form method="post" action="<?php echo e(url('/ports/')); ?>/<?php echo e($port->id); ?>/edit">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id" value="<?php echo e($port->id); ?>">
                                <div class="form-group">
                                    <label>Name</label>
                                    <input class="form-control" name="name" value="<?php echo e($port->name); ?>">
                                </div>

                                <div class="form-group">
                                    <label>Location</label> <br>
                                    Longitude: <input class="form-control" name="longitude" value="<?php echo e($port->longitude); ?>">

                                    Latitude: <input class="form-control" name="latitude" value="<?php echo e($port->latitude); ?>">
                                </div>

                                <div class="form-group">
                                    <label>Country</label>
                                    <input class="form-control" name="country" value="<?php echo e($port->country); ?>">
                                </div>

                                <div class="form-group">
                                    <label>Description</label>
                                    <input class="form-control" name="description" value="<?php echo e($port->description); ?>">
                                </div>

                                <div class="form-group">
                                    <input type="submit" class="btn btn-primary">
                                </div>
                            </form>

                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>