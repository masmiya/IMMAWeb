<?php $__env->startSection('title', 'Products'); ?>
<?php $__env->startSection('header'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div id="wrapper">

        <!-- Navigation -->
        <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Products</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Product Information
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <form method=post action="<?php echo e(url('/products')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label>Category</label>
                                    <select class="form-control" name="category_id" value="<?php echo e($category_id); ?>">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <?php if($category_id == $category->id): ?>
                                            <option value="<?php echo e($category->id); ?>" selected><?php echo e($category->name); ?></option>
                                            <?php else: ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </form>

                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>IMMA ID Code</th>
                                    <th>Name</th>
                                    <th>Order</th>
                                    <th>Description</th>
                                    <th>Image</th>
                                    <th>Delete</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="odd gradeX datarow" data-id="<?php echo e($product->id); ?>">
                                        <td><?php echo e($product->id); ?></td>
                                        <td><?php echo e($product->imma_id_code); ?></td>
                                        <td><?php echo e($product->name); ?></td>
                                        <td><?php echo e($product->order); ?></td>
                                        <td><?php echo e($product->description); ?></td>
                                        <td><img src="<?= asset($product->image_url)?>" height="100"></td>
                                        <td class="center remove-row">
                                            <a href="<?php echo e(url('products/')); ?>/<?php echo e($product->id); ?>/delete">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr class="odd gradeA">
                                        <td colspan="5">No records</td>
                                    </tr>
                                <?php endif; ?>

                                </tbody>
                            </table>
                            <!-- /.table-responsive -->

                            <a class="btn btn-primary" href="<?php echo e(url('products/new')); ?>">Add Product</a>

                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $('#dataTables-example').DataTable({
                responsive: true
            });

            $('.datarow').click(function (e){
                var id = $(this).data('id')
                window.location.href = "<?php echo e(url('/products/')); ?>/" + id + "/edit"
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>