<html>
<body>
Please follow this <a href="<?php echo e($url); ?>">link</a> to upload document to slot <?php echo e($slot+1); ?>. <br>

<?php echo e($url); ?>


</body>
</html>