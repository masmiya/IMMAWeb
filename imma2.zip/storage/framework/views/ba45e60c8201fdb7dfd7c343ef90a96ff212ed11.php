<?php $__env->startSection('title', 'Edit Product'); ?>
<?php $__env->startSection('header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div id="wrapper">

        <!-- Navigation -->
        <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Edit Product</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Product Information
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">

                            <!-- /.table-responsive -->

                            <form method="post" action="<?php echo e(url('/products/')); ?>/<?php echo e($product->id); ?>/edit" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label>Category</label>
                                    <select class="form-control" name="category_id">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($category->id == $product->category_id): ?>
                                                <option value="<?php echo e($category->id); ?>" selected><?php echo e($category->name); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>IMMA ID Code</label>
                                    <input class="form-control" name="imma_id_code" value="<?php echo e($product->imma_id_code); ?>">
                                </div>

                                <div class="form-group">
                                    <label>Order</label>
                                    <input class="form-control" name="order" value="<?php echo e($product->order); ?>">
                                </div>

                                <div class="form-group">
                                    <label>Name</label>
                                    <input class="form-control" name="name" value="<?php echo e($product->name); ?>">
                                </div>

                                <div class="form-group">
                                    <label>Description</label>
                                    <input class="form-control" name="description" value="<?php echo e($product->description); ?>">
                                </div>

                                <div class="form-group">
                                    <label>Image</label>
                                    <input type="file" class="form-control" name="image">
                                </div>

                                <div class="form-group">
                                    <label>RecQuantity10</label>
                                    <input class="form-control" name="req_quantity_10" value="<?php echo e($product->req_quantity_10); ?>">
                                </div>

                                <div class="form-group">
                                    <label>RecQuantity20</label>
                                    <input class="form-control" name="req_quantity_20" value="<?php echo e($product->req_quantity_20); ?>">
                                </div>

                                <div class="form-group">
                                    <label>RecQuantity30</label>
                                    <input class="form-control" name="req_quantity_40" value="<?php echo e($product->req_quantity_30); ?>">
                                </div>

                                <div class="form-group">
                                    <label>RecQuantity40</label>
                                    <input class="form-control" name="req_quantity_30" value="<?php echo e($product->req_quantity_40); ?>">
                                </div>

                                <div class="form-group">
                                    <label>Comment</label>
                                    <input class="form-control" name="comment" value="<?php echo e($product->comment); ?>">
                                </div>

                                <div class="form-group">
                                    <label>More than 24</label>
                                    <input class="form-control" name="more_than_24" value="<?php echo e($product->more_than_24); ?>">
                                </div>

                                <div class="form-group">
                                    <label>Less than 24</label>
                                    <input class="form-control" name="less_than_24" value="<?php echo e($product->less_than_24); ?>">
                                </div>

                                <div class="form-group">
                                    <label>Less than 2</label>
                                    <input class="form-control" name="less_than_2" value="<?php echo e($product->less_than_2); ?>">
                                </div>

                                <div class="form-group">
                                    <label>Dosage</label>
                                    <input class="form-control" name="dosage" value="<?php echo e($product->dosage); ?>">
                                </div>

                                <div class="form-group">
                                    <label>Reference</label>
                                    <input class="form-control" name="reference" value="<?php echo e($product->reference); ?>">
                                </div>

                                <div class="form-group">
                                    <label>Ordering Size</label>
                                    <input class="form-control" name="ordering_size" value="<?php echo e($product->ordering_size); ?>">
                                </div>

                                <div class="form-group">
                                    <label>Quantity Required</label>
                                    <input class="form-control" name="quantity_required" value="<?php echo e($product->quantity_required); ?>">
                                </div>


                                <div class="form-group">
                                    <input type="submit" class="btn btn-primary">
                                </div>
                            </form>

                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->

                    <div class="panel panel-default">
                        <div class="panel-heading">
                            SubProduct Information
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>IMMA ID Code</th>
                                    <th>Description</th>
                                    <th>Image</th>
                                    <th>Delete</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $subproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="odd gradeX datarow" data-id="<?php echo e($product->id); ?>" data-subid="<?php echo e($subproduct->id); ?>">
                                        <td><?php echo e($subproduct->id); ?></td>
                                        <td><?php echo e($subproduct->imma_id_code); ?></td>
                                        <td><?php echo e($subproduct->description); ?></td>
                                        <td><img src="<?= asset($subproduct->image_url)?>" height="100" ></td>
                                        <td class="center remove-row">
                                            <a href="<?php echo e(url('products/')); ?>/<?php echo e($product->id); ?>/subproducts/<?php echo e($subproduct->id); ?>/delete">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr class="odd gradeA">
                                        <td colspan="5">No records</td>
                                    </tr>
                                <?php endif; ?>

                                </tbody>
                            </table>

                            <a class="btn btn-primary" href="<?php echo e(url('products/')); ?>/<?php echo e($product->id); ?>/subproducts/new">Add SubProduct</a>
                        </div>
                    </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $('#dataTables-example').DataTable({
                responsive: true
            });

            $('.datarow').click(function (e){
                var id = $(this).data('id')
                var subid = $(this).data('subid')
                window.location.href = "<?php echo e(url('/products/')); ?>/" + id + "/subproducts/" + subid + "/edit"
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>